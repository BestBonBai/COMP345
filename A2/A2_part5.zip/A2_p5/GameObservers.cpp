#include "GameObservers.h"
#include "GameEngine.h"

GameObservers::~GameObservers()
{

}

GameObservers::GameObservers()
{
}

GameSubject::GameSubject()
{
	_observers = new list<GameObservers*>;
}

GameSubject::~GameSubject()
{
	delete _observers;
}

void GameSubject::Attach(GameObservers * o)
{
	_observers->push_back(o);
}

void GameSubject::Detach(GameObservers * o)
{
	_observers->remove(o);
}

void GameSubject::Notify()
{
	list<GameObservers *>::iterator i = _observers->begin();
	for (; i != _observers->end(); ++i)
		(*i)->Update();
}

PhaseObserver::PhaseObserver()
{
}

PhaseObserver::PhaseObserver(GameEngine* an_subject_Engine)
{
	//upon instanciation, attach itself to a GameEngine(Model)
	/*an_subject_Engine->Attach(this);
	this->subject_gameEngine = an_subject_Engine;*/
	this->subject_gameEngine = an_subject_Engine;
	this->subject_gameEngine->Attach(this);

}

PhaseObserver::~PhaseObserver()
{
	//upon destruction, detaches itself
	subject_gameEngine->Detach(this);
}

void PhaseObserver::Update()
{
	//called by Notify() when state of Subject changes
	display();
}

void PhaseObserver::display()
{
	player_name = subject_gameEngine->getCurrentPlayerName();
	phase_name = subject_gameEngine->getCurrentPhaseName();
	//player_name = "ssssss";
	//waiting other parts
	//cout << "PhaseObserver: " << player_name << " is in " << phase_name <<"\n" << endl;
	if (subject_gameEngine->getPhaseStatus() == 0) {
		cout << "PhaseObserver: " << player_name << " is in the " << phase_name << endl;
		//(1,2) display the correct player:phase information
		//cout << "PhaseObserver: " << player_name << " is in " << phase_name <<" \n" << endl;
	}
	if (subject_gameEngine->getPhaseStatus() == 1) {
		//(3) display relevant information which is different for every phase. 
		cout << " Observering Reinforcement Phase information is : \n";
		cout << "Orders : ";
		subject_gameEngine->getCurrentPlayer()->printOrder();
		cout << "Armies : " << subject_gameEngine->getCurrentPlayer()->getArmy();
		cout << endl;
	}
	if (subject_gameEngine->getPhaseStatus() == 2) {
		//(3) display relevant information which is different for every phase. 
		cout << " Observering Issuing Orders Phase information is : \n";
		cout << "Orders : ";
		subject_gameEngine->getCurrentPlayer()->printOrder();
		cout << "Armies : " << subject_gameEngine->getCurrentPlayer()->getArmy();
		cout << endl;
	}
	if (subject_gameEngine->getPhaseStatus() == 3) {
		//(3) display relevant information which is different for every phase. 
		cout << " Observering Orders Execution Phase information is : \n";
		cout << "Orders : ";
		subject_gameEngine->getCurrentPlayer()->printOrder();
		cout << "Armies : " << subject_gameEngine->getCurrentPlayer()->getArmy();
		cout << endl;
	}
	subject_gameEngine->setPhaseStatus(-1);//reset phase status
}



GameStatisticsObserver::GameStatisticsObserver()
{
}

GameStatisticsObserver::GameStatisticsObserver(GameEngine * a_subject_engine)
{
	this->subject_engine = a_subject_engine;
	this->subject_engine->Attach(this);

}

GameStatisticsObserver::~GameStatisticsObserver()
{
	subject_engine->Detach(this);
}

void GameStatisticsObserver::Update()
{
	//called by Notify() when state of Subject changes
	display();
}

void GameStatisticsObserver::display()
{
	if (subject_engine != nullptr) {
		//shows the percentage of the world using graph or table

		//(1)the game statistics view updates itself every time a country has been conquered by a player
		totalContinent = subject_engine->getTotalContinentNum();
		cout << "\n GameStatisticsObserver�� total number of continents is " << totalContinent << endl;

		if (subject_engine->getConcorquedStatus() == true) {
			conquredContinent = subject_engine->getConquredCountryName();
			cout << " GameStatisticsObserver : coquered country is " << conquredContinent << endl;
			//(2)a player has been eliminated and removes this player from the view;
			cout << " GameStatisticsObserver�� removed player is " << subject_engine->getRemovedPlayer()->getName() << " \n " << endl;
			
			subject_engine->setConcorquedStatus(false);//reset concorqued status
		}
		//(3)display a celebratory message
		winnerStatus = subject_engine->getWinStatus();
		if (winnerStatus == true)
		{
			cout << "GameStatisticsObserver�� The winner player is " << subject_engine->getWinnerPlayer()->getName() << endl;
		}

	}
}

//ConcreteSubject_GameEngine::ConcreteSubject_GameEngine()
//{
//}
//
//ConcreteSubject_GameEngine::~ConcreteSubject_GameEngine()
//{
//}
//
//void ConcreteSubject_GameEngine::set_concrete_gameEngine(GameEngine& _GameEngine)
//{
//	this->a_GameEngine = &_GameEngine;
//}
//
//GameEngine* ConcreteSubject_GameEngine::get_concrete_gameEngine()
//{
//	return a_GameEngine;
//}
