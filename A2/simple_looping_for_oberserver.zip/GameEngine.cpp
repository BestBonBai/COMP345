//altered
#include "GameEngine.h";
#include <iomanip>

//default constructor
GameEngine::GameEngine() {
	this->userInputMap = "";
	this->userInputPlayerQuantity = 0;
}

//two parameter constructor(optional,for gameStartNew() only)
GameEngine::GameEngine(string s, int i) {
	this->userInputMap = s;
	this->userInputPlayerQuantity = i;
	gameStart();
}

//assignment operator
GameEngine& GameEngine::operator=(const GameEngine& game_engine)
{
	userInputMap = game_engine.userInputMap;
	userInputPlayerQuantity = game_engine.userInputPlayerQuantity;
	map = game_engine.map;
	map_loader = game_engine.map_loader;
	player_list = game_engine.player_list;
	deck = game_engine.deck;
	return *this;
}

//destructor
GameEngine::~GameEngine() {
	delete map; map = nullptr;
	delete map_loader; map_loader = nullptr;
	delete[] player_list; player_list = nullptr;
	delete deck; deck = nullptr;
	for (int i = 0; i < TerritoryQuantity; i++) {
		delete territory_array[i];
	}
}

//accessor
string GameEngine::getUserInputMap() {
	return this->userInputMap;
}

//accessor
int GameEngine::getUserInputPlayerQuantity() {
	return this->userInputPlayerQuantity;
}

//mutator
void GameEngine::setUserInputMap(string s) {
	this->userInputMap = s;
}

//mutator
void GameEngine::setUserInputPlayerQuantity(int i) {
	this->userInputPlayerQuantity = i;
}

//methord to initialize a game
void GameEngine::gameStart() {
	//call MapLoader and Map object to generate a map graph
	cout << "\n<Generated Index of Territories>" << endl;
	string mapLoaded = "map" + userInputMap + ".txt";
	map_loader = new MapLoader(mapLoaded, TerritoryQuantity);
	map = new Map(TerritoryQuantity);
	for (int i = 0; i < TerritoryQuantity; i++) {
		map->territoryList[i] = map_loader->territoryArray[i];
	}

	//initialize empty attributes for each player
	vector<string*> territory;
	vector<string*> card;
	vector<Order*> order;

	//create and display players according to user inputed quantity
	cout << "\n<Participating Player List>" << endl;
	player_list = new Player[userInputPlayerQuantity];
	for (int i = 0; i < userInputPlayerQuantity; i++) {
		player_list[i] = Player(playerNameArr[i], territory, card, order);
		cout << player_list[i].getName() << endl;
	}

	//create edges for the game map
	cout << "\n<Generated Map Structure>" << endl;
	map->addEdge(0, 1);
	map->addEdge(0, 4);
	map->addEdge(1, 2);
	map->addEdge(1, 5);
	map->addEdge(2, 3);
	map->addEdge(2, 6);
	map->addEdge(3, 7);
	map->addEdge(4, 5);
	map->addEdge(5, 6);
	map->addEdge(5, 8);
	map->addEdge(6, 7);
	map->addEdge(8, 9);
	map->toString();
	if (map->Validate())
		cout << "Generated Map is a connected graph!!\n" << endl;
	else
		cout << "Caution! Generated Map is not connected graph!!\n" << endl;

	//initialize a card deck
	cout << "<Initial Card Deck Status>" << endl;
	deck = new Deck;
	deck->initial_vec_deck();
	deck->print_vec_deck();

	//part 5
	bool ob1 = false;//initial false
	bool ob2 = false;
	activeObservers();

}

//accessor
Map* GameEngine::getMap() {
	return map;
}

//accessor
Player* GameEngine::getPlayerList() {
	return player_list;
}

//accessor
int GameEngine::getTerritoryQuantity() {
	return this->TerritoryQuantity;
}

//method to start the game and initialize players
void GameEngine::startupPhase(int playerQuantity, int orderQuantity, int reinforcement) {
	//assign territory to players in round-robin fashion
	cout << "\n     Territory   " << "         Owner" << endl;
	for (int i = 0; i < TerritoryQuantity; i++) {
		territory_array[i] = new Territory();
		territory_array[i]->setTerritoryOwner((player_list + (i % playerQuantity))->getName());
		territory_array[i]->setTname(*((map->getTerritoryList()) + i));
		cout << setw(12) << territory_array[i]->getTname() << setw(20) << territory_array[i]->getTerritoryOwner() << endl;
	}

	//initialize army(amount of reinforcement) to each player 
	for (int k = 0; k < playerQuantity; k++) {
		(player_list + k)->setArmy(reinforcement);
		//cout << (p_list + i)->getArmy() << endl;
	}

	//assign random orders to each player
	const int o_range = 6;
	srand(time(NULL));
	//int o_index = (rand() % o_range);
	for (int j = 0; j < orderQuantity; j++) {
		for (int i = 0; i < playerQuantity; i++) {
			(player_list + i)->issueOrder(orderPool[(rand() % o_range)]);
		}
	}

	//display each player's initial status
	cout << "\n\n<Initialized status for each player>" << endl;
	for (int m = 0; m < playerQuantity; m++) {
		cout << "\n[player" << (m + 1) << "]" << endl;
		cout << "orders: ";
		(player_list + m)->printOrder();
		cout << "armies:";
		cout << (player_list + m)->getArmy();
		cout << endl;

		//part 5
		setCurrentPlayerName((player_list + m)->getName());
		setCurrentPhaseName("Initial Phase");//test observer
		setPhaseStatus(0); //set status as initial phase

		setCurrentPlayer((player_list + m));
		if (m == 0) {
			setPhaseStatus(1);
		}
		if (m == 1) {
			setPhaseStatus(2);
		}
		if (m == 2) {
			setPhaseStatus(3);
		}

		//test Part5 (GameStatisticObserver)
	   //set totalContinentNum, winner player, removerd player
		setTotalContinentNum(TerritoryQuantity - m);
		setConquredCountryName(territory_array[m]->getTname());//set conquredcCountry name
		//set conqured status
		setConcorquedStatus(true);
		setRemovedPlayer((player_list + m)); //player1 removed
		setWinnerPlayer(player_list);

		this->Notify(); //notify observe
	}
	//test Part5 (GameStatisticObserver)
	//set winner player, removerd player
	//setRemovedPlayer(this->getPlayerList()); //player1 removed
	setWinStatus(true);//set win status
	//setWinnerPlayer((this->getPlayerList() + 1));
	this->Notify();
}

void GameEngine::setObserverStatus(bool observer1, bool observer2)
{
	this->ob1 = observer1;
	this->ob2 = observer2;
}

void GameEngine::activeObservers()
{

	string str1, str2;
	cout << "\n Choose if turn on/off the PhaseObserver (yes or no) " << endl;
	cin >> str1;

	/*if (str1.compare("yes") == 0)
	{
		cout << "\n ......starting phaseobserver... \n" << endl;
		newView1 = new PhaseObserver(this);
	}*/

	cout << "Choose if turn on/off the GameStatisticsObserver (yes or no) " << endl;
	cin >> str2;
	//case1: turn on phaseobserver, turn off GameStatisticsObserver
	if (str1.compare("yes") == 0 && str2.compare("no") == 0)
	{
		if (ob2 == true)
		{
			cout << "\n ......closing GameStatisticsObserver... \n" << endl;
			this->Detach(newView2);
		}
		cout << "\n ......starting PhaseObserver... \n" << endl;
		newView1 = new PhaseObserver(this);
		setObserverStatus(true, false);
	}
	else if (str1.compare("no") == 0 && str2.compare("yes") == 0)
	{
		//case2: turn off phaseobserver, turn on GameStatisticsObserver 
		if (ob1 == true) {
			cout << "\n ......closing PhaseObserver... \n" << endl;
			this->Detach(newView1);
		}
		//create subject and observer
		cout << "\n ......starting GameStatisticsObserver... \n" << endl;
		newView2 = new GameStatisticsObserver(this);
		setObserverStatus(false, true);
	}
	else if (str1.compare("yes") == 0 && str2.compare("yes") == 0)
	{
		//case3: turn on both observers
		setObserverStatus(true, true);
		//create subject and observer
		cout << "\n ......starting PhaseObserver and GameStatisticsObserver... \n" << endl;
		newView1 = new PhaseObserver(this);
		newView2 = new GameStatisticsObserver(this);
	}
	else if (str1.compare("no") && str2.compare("no"))
	{
		//case4: turn off both observers
		if (ob1 == true && ob2 == true)
		{
			cout << "\n ......closing PhaseObserver and GameStatisticsObserver... \n" << endl;
			this->Detach(newView1);
			this->Detach(newView2);
		}
		setObserverStatus(false, false);

	}
	else {
		//other cases
		cout << "Please enter correct string (yes or no) --- failed observer ---" << endl;
	}

}

void GameEngine::setRemovedPlayer(Player* onePlayer)
{
	this->removedPlayer = onePlayer;
}

Player* GameEngine::getRemovedPlayer()
{
	return removedPlayer;
}

void GameEngine::setWinnerPlayer(Player* aWinnerPlayer)
{
	this->winnerPlayer = aWinnerPlayer;
}

Player* GameEngine::getWinnerPlayer()
{
	return winnerPlayer;
}

void GameEngine::setWinStatus(bool aStatus)
{
	this->winstatus = aStatus;
}

bool GameEngine::getWinStatus()
{
	return winstatus;
}

void GameEngine::setCurrentPlayerName(string pname)
{
	current_player_name = pname;
}

string GameEngine::getCurrentPlayerName()
{
	return current_player_name;
}

void GameEngine::setCurrentPhaseName(string phname)
{
	current_phase_name = phname;
}

string GameEngine::getCurrentPhaseName()
{
	return current_phase_name;
}

void GameEngine::setCurrentPlayer(Player* p)
{
	current_player = p;
}

Player* GameEngine::getCurrentPlayer()
{
	return current_player;
}

void GameEngine::setTotalContinentNum(int cnum)
{
	totalContinentNum = cnum;
}

int GameEngine::getTotalContinentNum()
{
	return totalContinentNum;
}

void GameEngine::setConquredCountryName(string cqname)
{
	conquredCountryName = cqname;
}

string GameEngine::getConquredCountryName()
{
	return conquredCountryName;
}

void GameEngine::setPhaseStatus(int pnum)
{
	phaseStatusNum = pnum;
}

int GameEngine::getPhaseStatus()
{
	return phaseStatusNum;
}

void GameEngine::setConcorquedStatus(bool c)
{
	conquredStatus = c;
}

bool GameEngine::getConcorquedStatus()
{
	return conquredStatus;
}

//added for looping
void GameEngine::gameLooping() {
	vector <Player> vplayer;
	const int o_range = 6;
	int player_remained = userInputPlayerQuantity;
	srand(time(NULL));
	for (int i = 0; i < player_remained; i++) {
		//put all players into a vector
		vplayer.push_back(Player(i + 1));
		//initialize army
		vplayer.at(i).setArmy((player_list + i)->getArmy());
		vplayer.at(i).pterritory = (10 / userInputPlayerQuantity);
	}

	for (int r = 1; r < 100; r++) {
		cout << "\nround[" << r << "]" << endl;

		//pick a random player for attribute modification
		int index = rand() % player_remained;
		if ((rand() % 11) < 5) {
			//decrement of army and territory of picked player by 1
			vplayer.at(index).setArmy(vplayer.at(index).getArmy()-10);
			vplayer.at(index).pterritory -= 1;
		}
		else {
			//increment of army and territory of picked player by 1
			vplayer.at(index).setArmy(vplayer.at(index).getArmy() + 5);
			vplayer.at(index).pterritory += 1;
		}

		for (int m = 0; m < player_remained; m++) {
			//give a random order to each player at each round
			vplayer.at(m).porder = (orderPool[(rand() % o_range)]);
			
			//check if any player need to be removed
			if ( (vplayer.at(m).pterritory <= 0) || (vplayer.at(m).getArmy() <= 0) ) {
				player_remained -= 1;
				cout << vplayer.at(m).getName() << " has been removed!!" << endl;
				vplayer.erase(vplayer.begin() + m);
				
				//the last remained player is the winner
				if (player_remained == 1) {
					cout << "\nCongratulations! Winner is " << vplayer.at(0).getName() << "!!";
					exit(0);
				}
			}
			
		}
			
	}
	
}

