#include "GameEngine.h";

//default constructor
GameEngine::GameEngine() {
    this->userInputMap = "";
    this->userInputPlayerQuantity = 0;
}

//two parameter constructor(optional,for gameStartNew() only)
GameEngine::GameEngine(string s, int i) {
	this->userInputMap = s;
	this->userInputPlayerQuantity = i;
    gameStart();
}

//assignment operator
GameEngine& GameEngine::operator=(const GameEngine& game_engine)
{
    userInputMap = game_engine.userInputMap;
    userInputPlayerQuantity = game_engine.userInputPlayerQuantity;
    map = game_engine.map;
    map_loader = game_engine.map_loader;
    player_list = game_engine.player_list;
    deck = game_engine.deck;
    return *this;
}

//destructor
GameEngine::~GameEngine() {
    delete map; map = nullptr;
    delete map_loader; map_loader = nullptr;
    delete[] player_list; player_list = nullptr;
    delete deck; deck = nullptr;
}

//accessor
string GameEngine::getUserInputMap() {
	return this->userInputMap;
}

//accessor
int GameEngine::getUserInputPlayerQuantity() {
	return this->userInputPlayerQuantity;
}

//mutator
void GameEngine::setUserInputMap(string s) {
	this->userInputMap = s;
}

//mutator
void GameEngine::setUserInputPlayerQuantity(int i) {
	this->userInputPlayerQuantity = i;
}

//methord to initialize a game
void GameEngine::gameStart() {
    //call MapLoader and Map object to generate a map graph
    cout << "\n<Generated Index of Territories>" << endl;
    string mapLoaded = "map" + userInputMap + ".txt";
    map_loader = new MapLoader(mapLoaded, TerritoryQuantity);
    map = new Map(TerritoryQuantity);
    for (int i = 0; i < TerritoryQuantity; i++) {
        map->territoryList[i] = map_loader->territoryArray[i];
    }

    //initialize empty attributes for each player
    vector<string*> territory;
    vector<string*> card;
    vector<Order*> order{&Order (),&Order ()};
    
    //create and display players according to user inputed quantity
    cout << "\n<Participating Player List>" << endl;
    player_list = new Player[userInputPlayerQuantity];
    const string playerNameArr[] = { "Player1","Player2","Player3","Player4","Player5" };
    for (int i = 0; i < userInputPlayerQuantity; i++) {
        player_list[i] = Player(playerNameArr[i],territory,card,order);
        cout << player_list[i].getName() << endl;
    }

    //create edges for the game map
    cout << "\n<Generated Map Structure>" << endl;
    map->addEdge(0, 1);
    map->addEdge(0, 4);
    map->addEdge(1, 2);
    map->addEdge(1, 5);
    map->addEdge(2, 3);
    map->addEdge(2, 6);
    map->addEdge(3, 7);
    map->addEdge(4, 5);
    map->addEdge(5, 6);
    map->addEdge(5, 8);
    map->addEdge(6, 7);
    map->addEdge(8, 9);
    map->toString();
    if (map->Validate())
        cout << "Generated Map is a connected graph!!\n" << endl;
    else
        cout << "Caution! Generated Map is not connected graph!!\n" << endl;

    //initialize a card deck
    cout << "<Initial Card Deck Status>" << endl;
    deck = new Deck;
    deck->initial_vec_deck();
    deck->print_vec_deck();

}