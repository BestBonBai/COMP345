#include "Player.h"

using namespace std;

//Default constructor
Player::Player()
{
	string name = "Null";
}

//added constructor
Player::Player(string s)
{
	this->name = s;
	vector<string*> terriorty;
	vector<string*> handCard;
	vector<Order*> orderList;
}

Player::Player(string name, vector<string*> t, vector<string*> h, vector<Order*> o)
{
	this->name = name;
	this->terriorty = t;
	this->handCard = h;
	this->orderList = o;
}



//Copy constructor (Deep copy)
Player::Player(const Player& p)
{
	this->name = p.name;
	this->terriorty = p.terriorty;
	this->handCard = p.handCard;
	this->orderList = p.orderList;

}

//added assignment operator
Player& Player::operator=(const Player& player)
{
	this->name = player.name;
	return *this;
}

//Destructor
Player::~Player()
{
	//release memory
	vector<string*>().swap(terriorty);
	vector<string*>().swap(handCard);
	vector<Order*>().swap(orderList);
}

//added
string Player::getName() {
	return this->name;
}

void Player::toAttack()
{
	cout << "The list of territories that are be attacked" << endl;
	for (int i = 0; i < terriorty.size(); i++)
	{
		cout << *terriorty[i] << endl;
	}

	cout << endl;
}


void Player::toDefend()
{

	cout << "The list of territories that are be defended" << endl;
	for (int i = 0; i < terriorty.size(); i++)
	{
		cout << *terriorty[i] << endl;
	}
	cout << endl;
}


void Player::issueOrder(string order)
{
	Order* a = new Order(order);

	orderList.push_back(a);

}

vector<Order*> Player::getOrderList()
{

	return orderList;
}


void Player::printOrder()
{
	cout << "The list of Player's orders" << endl;
	vector<Order*>::iterator it = orderList.begin();
	for (; it != orderList.end(); it++)
	{
		cout << (*it)->getResult() << endl;
	}
	cout << endl;
}

void Player::printHandcard()
{
	cout << "The list of Player's handcard" << endl;
	for (int i = 0; i < handCard.size(); i++)
	{
		cout << *handCard[i] << endl;
	}
	cout << endl;


}