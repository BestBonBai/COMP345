//altered
#include "Player.h"

using namespace std;

//Default constructor
Player::Player()
{
	name = "default";
}

//added constructor
Player::Player(string s)
{
	this->name = s;

}

Player::Player(string name, vector<string*> t, vector<string*> h, vector<Order*> o)
{
	this->name = name;
	this->territoryList = t;
	this->handCard = h;
	this->orderList = o;
}



//Copy constructor (Deep copy)
Player::Player(const Player& p)
{
	this->name = p.name;
	this->territoryList = p.territoryList;
	this->handCard = p.handCard;
	this->orderList = p.orderList;
	this->pterritory = p.pterritory;
	this->army = p.army;
}

//added assignment operator
Player& Player::operator=(const Player& player)
{
	this->name = player.name;
	this->army = player.army;
	this->territoryList = player.territoryList;
	this->handCard = player.handCard;
	this->orderList = player.orderList;
	return *this;
}

//Destructor
Player::~Player()
{
	//release memory
	vector<string*>().swap(territoryList);
	vector<string*>().swap(handCard);
	vector<Order*>().swap(orderList);
}

//added
string Player::getName() {
	return this->name;
}

void Player::setName(string s) {
	this->name = s;
}

int Player::getArmy() {
	return this->army;
}

void Player::setArmy(int i) {
	this->army = i;
}

void Player::toAttack()
{
	cout << "The list of territories that are be attacked" << endl;
	for (int i = 0; i < territoryList.size(); i++)
	{
		cout << *territoryList[i] << endl;
	}

	cout << endl;
}


void Player::toDefend()
{

	cout << "The list of territories that are be defended" << endl;
	for (int i = 0; i < territoryList.size(); i++)
	{
		cout << *territoryList[i] << endl;
	}
	cout << endl;
}


void Player::issueOrder(string order)
{
	Order* a = new Order(order);

	orderList.push_back(a);

}

vector<Order*> Player::getOrderList()
{

	return orderList;
}


void Player::printOrder()
{
	/*
	//cout << "The list of Player's orders" << endl;
	vector<Order*>::iterator it = orderList.begin();
	for (; it != orderList.end(); it++)
	{
		cout << ((*it)->getResult());
	}
	*/
	for (int i = 0; i < orderList.size(); i++) {
		cout << "<" << orderList.at(i)->getResult() << "> ";
	}
	cout << endl;
}

void Player::printHandcard()
{
	cout << "The list of Player's handcard" << endl;
	for (int i = 0; i < handCard.size(); i++)
	{
		cout << *handCard[i] << endl;
	}
	cout << endl;


}

Player::Player(int i) {
	this->name = "Player" + to_string(i);
}
/*
void Player::addTerritory(string s) {
	Territory* t = new Territory(s);
	string* str;
	*str = t->getTname();
	territoryList.push_back(str);
}

void Player::printPlayerOwnedTerritory() {
	vector<string*>::iterator it = territoryList.begin();
	for (; it != territoryList.end(); it++)
	{
		cout << (*it) << ", ";
	}
	cout << endl;
}

void Player::removeTerritory(string s) {
	//TBD
}
*/