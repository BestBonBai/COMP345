#include <iomanip>
#include "GameEngine.h";

//driver to initialize a game with two user inputs(mapIndex & playerQuanatity)
void main() {
    string inputMapIndex;
    int inputPlayerQuantity;
        
    //promt user to choose map1 or map2 as valid input, otherwise terminate the program
    cout << "Availabe Game Map List: Map1(Valid), Map2(Valid), Map3(Invalid)\n";
    cout << "Please enter the Map Index(1/2/3) for your game:\n";
    cin >> inputMapIndex;
    switch (inputMapIndex.at(0)) {
        case '1': 
            cout << "Map1 successfully loaded!\n" << endl;
            break;
        case '2':
            cout << "Map2 successfully loaded!\n" << endl;
            break;
        case '3':
            cout << "Map3 successfully loaded!\n" << endl;
            break;
        default:
            cout << "Invalid map file, program terminated!!" << endl;
            exit(0);
     }
    
    //promt user to enter valid player number, otherwise terminate the program
    cout << "Please enter the number of players(2/3/4/5):\n";
    cin >> inputPlayerQuantity;
    switch (inputPlayerQuantity) {
    case 2:
        cout << "2 Players created!\n" << endl;
        break;
    case 3:
        cout << "3 Players created!\n" << endl;
        break;
    case 4:
        cout << "4 Players created!\n" << endl;
        break;
    case 5:
        cout << "5 Players created!\n" << endl;
        break;
    default:
        cout << "Invalid Player number, program terminated!!" << endl;
        exit(0);
    }
    
    //pass the user inputed arguments to game initialization method
    GameEngine* game_engine = new GameEngine(inputMapIndex, inputPlayerQuantity);
        
    //call destructors to avoid memory leak
    delete game_engine; game_engine = nullptr;
    
}