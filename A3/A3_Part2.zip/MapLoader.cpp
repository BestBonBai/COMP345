#include <fstream>
#include <string>
#include "MapLoader.h"
#include "Map.h"

//default constructor
MapLoader::MapLoader() {
    setInputFileName("none");
    territoryArray = new string[10];
}

//copy constructor
MapLoader::MapLoader(const MapLoader* ml) {
    inputFileName = ml->inputFileName;
    territoryArray = ml->territoryArray;
}

//two parameters constructor
MapLoader::MapLoader(string fileName, int arraySize) {
    this->inputFileName = fileName;
    territoryArray = new string[arraySize];
    generateTerritoryArray(arraySize);
}

//assignment operator
MapLoader& MapLoader::operator = (const MapLoader& ml) {
    this->inputFileName = ml.inputFileName;
    territoryArray = ml.territoryArray;
    return *this;
}

//destructor
MapLoader::~MapLoader() {
    //inputFileName.clear();
    //territoryArray->clear();
    //territoryArray = NULL;
}

//accessor
string MapLoader::getInputFileName() {
    return inputFileName;
}

//mutator
void MapLoader::setInputFileName(string s) {
    inputFileName = s;
}

//collect territory names from valid input file, exit(0) if invalid input file
void MapLoader::generateTerritoryArray(int size) {
    int a, b, c, d;
    bool valid = false;
    string s;
    ifstream input(inputFileName);
    getline(input, s);
    while (!input.eof()) {
        if ((a = s.find("countries") != string::npos)) {
            valid = true;
            for (int i = 0; i < size; i++) {
   
             input >> a >> territoryArray[i] >> b >> c >> d;
            }
            cout << "Index     Territory" << endl;
            for (int i = 0; i < size; i++) {
                cout << "  " << i << "   :   " << territoryArray[i] << endl;
            }
        }
        if (input.eof()) {
        }

        else
            getline(input, s);

    }

    if (!valid) {
        cout << "Initialization failed! Invalid input map file! Program terminated!" << endl;
        exit(0);
    }

    input.close();
}


//default constructor
ConquestFileReader::ConquestFileReader() {
    inputFileNameConquest = "none";
}

//copy constructor
ConquestFileReader::ConquestFileReader(const ConquestFileReader* cfr) {
    inputFileNameConquest = cfr->inputFileNameConquest;
}

//two parameters constructor
ConquestFileReader::ConquestFileReader(string fileName, int arraySize) {
    this->inputFileNameConquest = fileName;
    territoryArrayConquest = new string[arraySize];
    generateTerritoryArrayConquest(arraySize);
}

//assignment operator
ConquestFileReader& ConquestFileReader::operator = (const ConquestFileReader& cfr) {
    this->inputFileNameConquest = cfr.inputFileNameConquest;
    return *this;
}

//destructor
ConquestFileReader::~ConquestFileReader() {
    inputFileNameConquest.clear();
    territoryArrayConquest->clear();
    territoryArrayConquest = NULL;
}

//accessor
string ConquestFileReader::getInputFileNameConquest() {
    return inputFileNameConquest;
}

//mutator
void ConquestFileReader::setInputFileNameConquest(string s) {
    inputFileNameConquest = s;
}

void ConquestFileReader::generateTerritoryArrayConquest(int size) {

    string s, p;
    int m;
    bool valid = false;
    ifstream inputConquest(getInputFileNameConquest());
    getline(inputConquest, s);
    while (!inputConquest.eof()) {
        if ((m = s.find("Territories") != string::npos)) {
            valid = true;
            for (int i = 0; i < size; i++) {
                inputConquest >> territoryArrayConquest[i] >> p;
            }
            cout << "Index     Territory" << endl;
            for (int i = 0; i < size; i++) {
                cout << "  " << i << "   :   " << territoryArrayConquest[i].substr(0,11) << endl;
            }
        }
        if (inputConquest.eof()) {
        }

        else
            getline(inputConquest, s);

    }

    if (!valid) {
        cout << "Initialization failed! Invalid input map file! Program terminated!" << endl;
        exit(0);
    }

    inputConquest.close();
}

//default constructor
ConquestFileReaderAdapter::ConquestFileReaderAdapter() {
    
}

//copy constructor
ConquestFileReaderAdapter::ConquestFileReaderAdapter(const ConquestFileReaderAdapter* cfra) : MapLoader(cfra) {
    cfr = cfra->cfr;
}

//two parameters constructor
ConquestFileReaderAdapter::ConquestFileReaderAdapter(string fileName, int arraySize) : MapLoader(), cfr(ConquestFileReader(fileName, arraySize)) {
     
}

//assignment operator
ConquestFileReaderAdapter& ConquestFileReaderAdapter::operator = (const ConquestFileReaderAdapter& cfra){
    MapLoader::operator=(cfra);
    this->cfr = cfra.cfr;
    return *this;
}

//destructor
ConquestFileReaderAdapter::~ConquestFileReaderAdapter() {
    
}
