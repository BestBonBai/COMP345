//altered
#pragma once
#include "Map.h"
#include "MapLoader.h"
#include "Card.h"
#include "Player.h"
#include "Orders.h"
#include "GameObservers.h"

class GameEngine : public GameSubject {
public:
	GameEngine();								//default constructor
	GameEngine(string, int);					//two parameter constructor
	~GameEngine();								//destructor
	GameEngine& operator = (const GameEngine&); //assignment operator
	string getUserInputMap();					//accessor
	int getUserInputPlayerQuantity();			//accessor
	void setUserInputMap(string);				//mutator
	void setUserInputPlayerQuantity(int);		//mutator
	void gameStart();							//methord to initialize a game
	int getTerritoryQuantity();					//accessor
	Map* getMap();								//accessor
	Player* getPlayerList();					//accessor
	void startupPhase(int, int, int);

	//Part 5: switch for 2 observers, observer1 = true/false is turn on/off phaseObserve, observer2 = true/false is turn on/off GameStatisticsObserver 
	void setObserverStatus(bool observer1, bool observer2);
	//active observers
	void activeObservers();
	//set removed player
	void setRemovedPlayer(Player* onePlayer);
	//get removed player
	Player* getRemovedPlayer();
	//set winner player
	void setWinnerPlayer(Player* aWinnerPlayer);
	//get winner player
	Player* getWinnerPlayer();
	//set win status
	void setWinStatus(bool aStatus);
	//get winStatus
	bool getWinStatus();
	//set current player name;
	void setCurrentPlayerName(string pname);
	//get CurrentPlayerName
	string getCurrentPlayerName();
	//set current phase name
	void setCurrentPhaseName(string phname);
	//get current phase name
	string getCurrentPhaseName();
	//set current player
	void setCurrentPlayer(Player* p);
	//get current player
	Player* getCurrentPlayer();
	//set totalContinentNum
	void setTotalContinentNum(int cnum);
	//get  totalContinentNum
	int getTotalContinentNum();
	//set conquredCountryName
	void setConquredCountryName(string cqname);
	//get conquredCountryName
	string getConquredCountryName();
	//set phase status: phase1, phase2, phase3
	void setPhaseStatus(int pnum);
	//get phase status: phase1, phase2, phase3 are 1,2,3 respectively
	int getPhaseStatus();
	//set concorqued status
	void setConcorquedStatus(bool c);
	//get concorqued status
	bool getConcorquedStatus();
	
	//added looping
	void gameLooping();
	

private:
	string userInputMap;						//user inputed map index
	int userInputPlayerQuantity;				//user inputed player quantity
	Map* map;									//initialized Map for the game
	MapLoader* map_loader;						//initialized MapLoader for the game
	Player* player_list;						//initialized Player Array for the gamePlayer array
	Deck* deck;									//initialized Deck for the game
	const int TerritoryQuantity = 10;			//initialize with ten territories
	const string playerNameArr[5] = { "Player1","Player2","Player3","Player4","Player5" }; // fixed five player names
	Territory* territory_array[10];				//Territory array

	//part 5
	bool ob1;
	bool ob2;//boolean for turn on/off observers
	PhaseObserver* newView1; //PhaseObserver
	GameStatisticsObserver* newView2;//GameStatisticsObserver
	Player* removedPlayer;//for removed player info
	Player* winnerPlayer;//for winner player info
	bool winstatus;//boolean for winner status
	string current_player_name;//current_player_name
	string current_phase_name;//current_phase_name
	Player* current_player;//current_player
	int totalContinentNum; //totalContinentNum
	string conquredCountryName;//conquredCountryName
	int phaseStatusNum; //phaseStatusNum
	bool conquredStatus;//conquredStatus
};
