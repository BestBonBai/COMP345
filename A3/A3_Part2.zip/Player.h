#pragma once
#include <string>
#include <vector>
#include <iostream>
#include "Orders.h"
#include "Map.h"
#include "Card.h"
using namespace std;

class Player {

public:
    Player();       // Default constructor
    Player(string); //added
    Player(string name, vector<string*> t, vector<string*> h, vector<Order*>); //Constructor
    Player(const Player&); //Copy constructor
    Player& operator = (const Player&); //added
    ~Player(); //Destructor
    void toAttack();
    void toDefend();
    void issueOrder(string);
    vector<Order*> getOrderList();
    void printOrder();
    void printHandcard();
    string getName(); 
    void setName(string);
    int getArmy();
    void setArmy(int);
    void addTerritory(string);
    void removeTerritory(string);
    void printPlayerOwnedTerritory();

private:
    string name;
    int army;
    vector<string*> territoryList;
    vector<string*> handCard;
    vector<Order*> orderList;
};

static int reinforcement;