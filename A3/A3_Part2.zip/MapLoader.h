#pragma once
#include <iostream>
using namespace std;

//declaration of MapLoader class with its members
class MapLoader {
public:
    MapLoader();                        //default constructor
    MapLoader(const MapLoader*);        //copy constructor
    MapLoader(string, int);            //two parameters constructor
    MapLoader& operator = (const MapLoader&); //assignment operator
    ~MapLoader();                       //destructor
    string* territoryArray;             //territory name array
    void generateTerritoryArray(int);   //collect territory name from input file
    string getInputFileName();          //accessor
    void setInputFileName(string);      //mutator
    string inputFileName;               //input file path
};

//class ConquestFileReader to read Conquest map file
class ConquestFileReader { 
public:
    ConquestFileReader();                           //default constructor
    ConquestFileReader(const ConquestFileReader*);  //copy constructor
    ConquestFileReader(string, int);                //two parameter constructor
    ConquestFileReader& operator = (const ConquestFileReader&); //assignment operator
    ~ConquestFileReader();                          //destructor
    string* territoryArrayConquest;                 //territory name array
    void generateTerritoryArrayConquest(int);       //collect territory name from input file
    string getInputFileNameConquest();              //accessor
    void setInputFileNameConquest(string);          //mutator
    string inputFileNameConquest;                   //store input file name
};

//adapter class to read Condquest map file from MapLoader class
class ConquestFileReaderAdapter : public MapLoader {
public:
    ConquestFileReaderAdapter();                                  //default constructor
    ConquestFileReaderAdapter(const ConquestFileReaderAdapter*);  //copy constructor
    ConquestFileReaderAdapter(string, int);                         //two parameter constructor
    ConquestFileReaderAdapter& operator = (const ConquestFileReaderAdapter&); //assignment operator
    ~ConquestFileReaderAdapter();                                  //destructor
    ConquestFileReader cfr;
};
