Team 23
Assignment 2:

Part1: Zhongqi Huang(40125425)

Part2: Ruoxi Ni(40125422)

Part3: Zixuan Tang(40024456)

Part4: Jiawei Zeng(40079344)

Part5: Hualin Bai(40053833)

