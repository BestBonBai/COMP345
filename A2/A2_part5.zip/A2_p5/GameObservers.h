#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm> //for sort, union, intersection method
#include <iterator> 
#include <iostream>
#include <list>
//#include "GameEngine.h"

using namespace std;

//(Part 5) observer pattern
//@author: Hualin Bai(40053833)
//class GameSubject;

//GameObservers is an observer class (abstract)
class GameObservers
{
public:
	//destructor
	~GameObservers();

	//update method
	virtual void Update() = 0;

private:
	
protected:
	GameObservers();

};


//subject (observable) base class
class GameSubject {
public:
	virtual void Attach(GameObservers* o);//attach method
	virtual void Detach(GameObservers* o);//detach method
	virtual void Notify();//notify method

	GameSubject();//constructor
	~GameSubject();//destructor

	

private:
	list<GameObservers*> *_observers;

};

//ConcreteSubject(Model) Class (inherit Subject)
//GameEngine as a Model  (test case)
//class ConcreteSubject_GameEngine : public GameSubject{
//public:
//	ConcreteSubject_GameEngine();
//	~ConcreteSubject_GameEngine();
//
//	void set_concrete_gameEngine(GameEngine& _GameEngine);
//	GameEngine* get_concrete_gameEngine();
//
//private:
//	GameEngine* a_GameEngine;
//
//};
class GameEngine;
//ConcreteObserver(View) Class (inherit Observer) includes (1)PhaseObserver and (2)GameStatisticsObserver
//(1) PhaseObserver Class (view)
class PhaseObserver : public GameObservers {
public:
	PhaseObserver();
	PhaseObserver(GameEngine* an_subject_Engine);
	~PhaseObserver();
	//update method
	void Update();

	//display a header showing what player and what phase is currently being played
	//then, display important information
	void display();


private:
	string player_name;//player name
	string phase_name;//phase name
	GameEngine* subject_gameEngine;//a gameEngine pointer

};

//(2) Game Statistics Observer
class GameStatisticsObserver : public GameObservers {
public:
	//constructor
	GameStatisticsObserver();
	GameStatisticsObserver(GameEngine* a_subject_engine);
	//destructor
	~GameStatisticsObserver();
	//update method
	void Update();
	//display some useful statistics about the game
	void display();

private:
	GameEngine* subject_engine; //a engine subject pointer
	int totalContinent; //total continent for game statistic
	bool winnerStatus;//boolean winnerStatus for game statistic
	string conquredContinent;//conquredContinent
};